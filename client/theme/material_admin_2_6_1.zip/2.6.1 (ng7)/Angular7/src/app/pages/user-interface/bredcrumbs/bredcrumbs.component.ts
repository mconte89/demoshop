import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bredcrumbs',
  templateUrl: './bredcrumbs.component.html'
})
export class BredcrumbsComponent implements OnInit {
  pageTitle: string = 'Breadcrumb';

  constructor() { }

  ngOnInit() {
  }

}
