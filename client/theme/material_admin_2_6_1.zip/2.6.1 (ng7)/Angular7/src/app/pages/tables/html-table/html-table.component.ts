import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-html-table',
  templateUrl: './html-table.component.html'
})
export class HtmlTableComponent implements OnInit {
  pageTitle: string = 'HTML TABLES'

  constructor() { }

  ngOnInit() {
  }

}
