import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-layouts',
  templateUrl: 'form-layouts.component.html'
})
export class FormLayoutsComponent implements OnInit {
  pageTitle: string = 'Form Layouts';

  constructor() { }

  ngOnInit() {
  }

}
